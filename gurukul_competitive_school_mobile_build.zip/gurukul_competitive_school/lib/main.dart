import 'package:flutter/material.dart';

void main() => runApp(const GurukulApp());

class GurukulApp extends StatelessWidget {
  const GurukulApp({super.key});

  static const navy = Color(0xFF102B55);
  static const gold = Color(0xFFD6A83E);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'GURUKUL COMPETITIVE SCHOOL',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: navy, primary: navy, secondary: gold),
        scaffoldBackgroundColor: const Color(0xFFF6F8FC),
        appBarTheme: const AppBarTheme(backgroundColor: navy, foregroundColor: Colors.white),
        cardTheme: CardThemeData(elevation: 1, color: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
      ),
      home: const LoginScreen(),
    );
  }
}

class BrandHeader extends StatelessWidget {
  const BrandHeader({super.key, this.compact = false});
  final bool compact;
  @override
  Widget build(BuildContext context) => Row(children: [
    Container(width: compact ? 42 : 54, height: compact ? 42 : 54,
      decoration: BoxDecoration(color: GurukulApp.gold, borderRadius: BorderRadius.circular(15)),
      child: const Icon(Icons.menu_book_rounded, color: GurukulApp.navy, size: 30)),
    const SizedBox(width: 12),
    const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('GURUKUL', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.4, color: GurukulApp.navy, fontSize: 20)),
      Text('COMPETITIVE SCHOOL', style: TextStyle(fontWeight: FontWeight.w700, letterSpacing: 1, color: GurukulApp.navy, fontSize: 11)),
    ])),
  ]);
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final name = TextEditingController();
  final mobile = TextEditingController();
  bool register = false;
  @override
  void dispose() { name.dispose(); mobile.dispose(); super.dispose(); }

  void enter() {
    if (mobile.text.trim().length < 10) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('कृपया 10 अंकों का मोबाइल नंबर दर्ज करें।')));
      return;
    }
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => HomeScreen(studentName: name.text.trim().isEmpty ? 'Student' : name.text.trim())));
  }

  @override
  Widget build(BuildContext context) => Scaffold(body: SafeArea(child: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
    const BrandHeader(), const SizedBox(height: 34),
    Container(padding: const EdgeInsets.all(22), decoration: BoxDecoration(color: GurukulApp.navy, borderRadius: BorderRadius.circular(24)), child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(Icons.school_rounded, color: GurukulApp.gold, size: 42), SizedBox(height: 12),
      Text('पढ़ाई ऐसी, सफलता पक्की!', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
      SizedBox(height: 6), Text('Learn • Practice • Test • Achieve', style: TextStyle(color: Colors.white70)),
    ])),
    const SizedBox(height: 28), Text(register ? 'Create Student Account' : 'Student Login', style: const TextStyle(fontSize: 23, fontWeight: FontWeight.bold, color: GurukulApp.navy)),
    const SizedBox(height: 16),
    if (register) TextField(controller: name, decoration: const InputDecoration(labelText: 'Student Name', prefixIcon: Icon(Icons.person_outline), border: OutlineInputBorder())),
    if (register) const SizedBox(height: 12),
    TextField(controller: mobile, keyboardType: TextInputType.phone, maxLength: 10, decoration: const InputDecoration(labelText: 'Mobile Number', prefixIcon: Icon(Icons.phone_android), border: OutlineInputBorder(), counterText: '')),
    const SizedBox(height: 18), FilledButton(onPressed: enter, style: FilledButton.styleFrom(backgroundColor: GurukulApp.navy, padding: const EdgeInsets.symmetric(vertical: 16)), child: Text(register ? 'Create Account (Demo)' : 'Continue (Demo)')),
    TextButton(onPressed: () => setState(() => register = !register), child: Text(register ? 'Already registered? Login' : 'New student? Register')),
    const SizedBox(height: 24), const Text('Founder & CEO: Sahitya Raj Ashwani\nDirector: Sahitya Raj Ashwani', textAlign: TextAlign.center, style: TextStyle(color: Colors.black54, height: 1.6)),
    const SizedBox(height: 8), const Text('Demo login only — OTP authentication is not connected.', textAlign: TextAlign.center, style: TextStyle(fontSize: 11, color: Colors.black45)),
  ])))));
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.studentName});
  final String studentName;
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int index = 0;
  @override
  Widget build(BuildContext context) {
    final pages = [
      HomeTab(studentName: widget.studentName),
      const CoursesTab(),
      const DashboardTab(),
      const AdminTab(),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('GURUKUL COMPETITIVE SCHOOL', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)), actions: [IconButton(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Notifications integration pending.'))), icon: const Icon(Icons.notifications_none))]),
      body: pages[index],
      bottomNavigationBar: NavigationBar(selectedIndex: index, onDestinationSelected: (v) => setState(() => index = v), destinations: const [
        NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
        NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'Courses'),
        NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'Dashboard'),
        NavigationDestination(icon: Icon(Icons.admin_panel_settings_outlined), selectedIcon: Icon(Icons.admin_panel_settings), label: 'Admin'),
      ]),
    );
  }
}

class HomeTab extends StatelessWidget {
  const HomeTab({super.key, required this.studentName});
  final String studentName;
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    const BrandHeader(), const SizedBox(height: 18),
    Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(gradient: const LinearGradient(colors: [GurukulApp.navy, Color(0xFF244C7D)]), borderRadius: BorderRadius.circular(22)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('नमस्ते, $studentName! 👋', style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)), const SizedBox(height: 8),
      const Text('अपने लक्ष्य की ओर आज एक कदम और बढ़ाएँ।', style: TextStyle(color: Colors.white70)), const SizedBox(height: 14),
      const Text('TARGET 90+', style: TextStyle(color: GurukulApp.gold, fontSize: 24, fontWeight: FontWeight.w900, letterSpacing: 1.5)),
    ])),
    const SizedBox(height: 22), const SectionTitle('Explore Your Classes'),
    Row(children: [Expanded(child: ClassCard(title: 'Class 10', subtitle: 'Science + Math', icon: Icons.science, color: const Color(0xFFE8F0FF))), const SizedBox(width: 12), Expanded(child: ClassCard(title: 'Class 12', subtitle: 'Full PCB', icon: Icons.biotech, color: const Color(0xFFFFF3D9)))]),
    const SizedBox(height: 22), const SectionTitle('Study Resources'),
    const FeatureTile(icon: Icons.picture_as_pdf, title: 'Handwritten PDF Notes', subtitle: 'Chapter-wise study material'),
    const FeatureTile(icon: Icons.play_circle_outline, title: 'Video Lectures & Online Classes', subtitle: 'Learn from recorded and live lessons'),
    const FeatureTile(icon: Icons.quiz_outlined, title: 'VVI Objective Questions', subtitle: 'Practice important board questions'),
    const FeatureTile(icon: Icons.assignment_outlined, title: 'Mock Tests & Results', subtitle: 'Test your preparation'),
    const SizedBox(height: 14),
    Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('PREMIUM BATCH', style: TextStyle(color: GurukulApp.navy, fontWeight: FontWeight.w900, fontSize: 17)), const SizedBox(height: 5), const Text('Unlock premium classes, notes and tests.'), const SizedBox(height: 12), Wrap(spacing: 8, runSpacing: 8, children: [OutlinedButton.icon(onPressed: () => _notice(context, 'WhatsApp admission link will be configured.'), icon: const Icon(Icons.chat), label: const Text('WhatsApp')), OutlinedButton.icon(onPressed: () => _notice(context, 'Admission phone number will be configured.'), icon: const Icon(Icons.call), label: const Text('Call')), FilledButton.icon(onPressed: () => _notice(context, 'Secure payment gateway / UPI setup is pending.'), icon: const Icon(Icons.payment), label: const Text('Pay Online'))])]))),
    const SizedBox(height: 12), const Text('Founder & CEO / Director: Sahitya Raj Ashwani', textAlign: TextAlign.center, style: TextStyle(color: Colors.black54, fontSize: 12)),
  ]);
}

void _notice(BuildContext context, String message) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));

class CoursesTab extends StatelessWidget {
  const CoursesTab({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: const [SectionTitle('Available Courses'), ClassCard(title: 'Class 10', subtitle: 'Science • Mathematics', icon: Icons.school, color: Color(0xFFE8F0FF)), SizedBox(height: 12), ClassCard(title: 'Class 12', subtitle: 'Physics • Chemistry • Biology', icon: Icons.biotech, color: Color(0xFFFFF3D9)), SizedBox(height: 18), SectionTitle('Content Access'), FeatureTile(icon: Icons.lock_open, title: 'Free Content', subtitle: 'Open resources for every learner'), FeatureTile(icon: Icons.workspace_premium, title: 'Premium Content', subtitle: 'Available to enrolled students')]);
}

class DashboardTab extends StatelessWidget {
  const DashboardTab({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: const [BrandHeader(), SizedBox(height: 20), SectionTitle('Student Dashboard'), Row(children: [Expanded(child: StatCard(value: '02', label: 'Courses')), SizedBox(width: 10), Expanded(child: StatCard(value: '00', label: 'Tests'))]), SizedBox(height: 12), Row(children: [Expanded(child: StatCard(value: '00', label: 'Results')), SizedBox(width: 10), Expanded(child: StatCard(value: '00', label: 'Notes'))]), SizedBox(height: 20), SectionTitle('Your Learning'), FeatureTile(icon: Icons.history, title: 'Recently Watched', subtitle: 'Your video history will appear here'), FeatureTile(icon: Icons.download_done, title: 'Downloaded Notes', subtitle: 'Your saved PDFs will appear here'), FeatureTile(icon: Icons.person_outline, title: 'Student Profile', subtitle: 'Profile and enrolled batch details')]);
}

class AdminTab extends StatelessWidget {
  const AdminTab({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: const [BrandHeader(), SizedBox(height: 20), SectionTitle('Admin Panel – Concept'), Text('Admin access must be protected by secure role-based authentication before launch.'), SizedBox(height: 12), FeatureTile(icon: Icons.people_outline, title: 'Manage Students', subtitle: 'View student accounts and enrollments'), FeatureTile(icon: Icons.picture_as_pdf, title: 'Manage PDF Notes', subtitle: 'Upload and organize chapter-wise notes'), FeatureTile(icon: Icons.video_library_outlined, title: 'Manage Videos', subtitle: 'Add recorded lessons and class links'), FeatureTile(icon: Icons.quiz_outlined, title: 'Manage Questions & Tests', subtitle: 'Create VVI questions and mock tests'), FeatureTile(icon: Icons.campaign_outlined, title: 'Manage Batches & Notices', subtitle: 'Publish batch details and announcements')]);
}

class SectionTitle extends StatelessWidget {
  const SectionTitle(this.title, {super.key});
  final String title;
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.only(bottom: 12), child: Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: GurukulApp.navy)));
}

class ClassCard extends StatelessWidget {
  const ClassCard({super.key, required this.title, required this.subtitle, required this.icon, required this.color});
  final String title, subtitle; final IconData icon; final Color color;
  @override
  Widget build(BuildContext context) => Card(child: Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(18)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(icon, color: GurukulApp.navy, size: 30), const SizedBox(height: 12), Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18, color: GurukulApp.navy)), Text(subtitle, style: const TextStyle(fontSize: 12, color: Colors.black87))])));
}

class FeatureTile extends StatelessWidget {
  const FeatureTile({super.key, required this.icon, required this.title, required this.subtitle});
  final IconData icon; final String title, subtitle;
  @override
  Widget build(BuildContext context) => Card(child: ListTile(leading: CircleAvatar(backgroundColor: const Color(0xFFE8EEF8), child: Icon(icon, color: GurukulApp.navy)), title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)), subtitle: Text(subtitle), trailing: const Icon(Icons.chevron_right)));
}

class StatCard extends StatelessWidget {
  const StatCard({super.key, required this.value, required this.label});
  final String value, label;
  @override
  Widget build(BuildContext context) => Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(children: [Text(value, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: GurukulApp.navy)), Text(label, style: const TextStyle(color: Colors.black54))])));
}
