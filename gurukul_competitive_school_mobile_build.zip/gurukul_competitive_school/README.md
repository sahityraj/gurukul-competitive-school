# GURUKUL COMPETITIVE SCHOOL — Flutter starter prototype

A starter Flutter Android app for the Gurukul Competitive School concept.

## Included in this prototype
- Login / registration UI (demo only; no real OTP or account creation)
- Home screen with Class 10 Science + Math and Class 12 PCB
- Study resource tiles for PDF notes, video lectures, VVI questions, mock tests and results
- Student dashboard with placeholder progress cards
- Admin panel concept for managing students, notes, videos, questions, tests, batches and notices
- WhatsApp, call and online payment placeholder actions
- Navy blue, white and gold branding
- Founder & CEO / Director: Sahitya Raj Ashwani

## Run locally
1. Install Flutter SDK and Android Studio.
2. From this directory run `flutter create .` if platform folders are not present.
3. Run `flutter pub get`.
4. Run `flutter run` on an Android emulator or connected device.

## Important: prototype limitations
This is a UI/starter-code prototype, not a production-ready APK. The login flow is a local demo and must be replaced with secure authentication and OTP verification. Content, PDFs, videos, tests, results, notifications and admin actions need a backend/database and protected admin roles. WhatsApp and phone actions need verified contact details and deep links. UPI/online payment needs an approved payment provider, merchant onboarding, server-side payment verification and secure handling; no real payment is processed by this prototype. Before release, add app icon/splash screen, privacy policy, terms, data protection, accessibility checks, device testing, release signing and Play Store compliance.

## Build an APK using only an Android phone (cloud build)
This repository includes `.github/workflows/build-android-apk.yml`. It uses GitHub Actions to create the Android platform folder and build a release APK in the cloud.

1. On your Android phone, open GitHub in Chrome and sign in (ask a parent/guardian to help with account setup if needed).
2. Create a new repository, for example `gurukul-competitive-school`.
3. Upload the contents of this project folder, keeping the `.github/workflows/build-android-apk.yml` file and its folders. If GitHub's mobile upload page hides dot-folders, use GitHub's web interface in Desktop site mode or ask someone with a computer to upload the project once.
4. Open the repository's **Actions** tab, select **Build Android APK**, and tap **Run workflow**.
5. When the workflow finishes successfully, open that run and download the artifact named `gurukul-competitive-school-apk`.
6. Extract the downloaded artifact ZIP on your phone. It contains `app-release.apk`. Only install builds from your own repository and review Android's install warning before proceeding.

The APK produced by this workflow is still a prototype. Demo login is not secure authentication, and backend content, real payment verification, notifications, privacy policy, release signing and device testing are not included. Do not collect student personal data or accept real payments until those systems are properly implemented and reviewed.
